setwd("~/Desktop/data")
library(tidyverse)
library(dplyr)
library(data.table)
library(psych)

# Подгружаем файл с данными, которые имеют разлелитель ";" и выбираем из него нужные нам колонки
dat <- as.data.frame(rbind(read.csv("12_main_exp_2017_Dec_01_1534.csv", header = T, sep = ";"), 
                           read.csv("11_main_exp_2017_Nov_30_2054.csv", header = T, sep = ";"))) 
dat <- dat[, c("participant", "key_resp_1.rt", "key_resp_1.corr", "set_type1",
               "key_resp_2.rt", "key_resp_2.corr", "set_type2", 
               "key_resp_3.rt", "key_resp_3.corr", "set_type3",
               "key_resp_4.rt", "key_resp_4.corr", "set_type4")]

# Подгружаем файл с названиями файлов эксперимента
expnames <- read.csv("expnames.csv", header = F)

# Подгружаем остальные файлы, выбираем из них нужные нам колонки и соединяем их все с предыдущим файлом
for (i in 1:nrow(expnames)) {
dat1 <- read.csv(as.character(expnames[i,]))
dat1 <- dat1[, c("participant", "key_resp_1.rt", "key_resp_1.corr", "set_type1",
                 "key_resp_2.rt", "key_resp_2.corr", "set_type2", 
                 "key_resp_3.rt", "key_resp_3.corr", "set_type3",
                 "key_resp_4.rt", "key_resp_4.corr", "set_type4")]
dat <- rbind(dat, dat1)
}

# Избавляемся от разделения на эксеприментальные блоки и приводим данные к длинному формату и попутно удаляем все наблюдения, когда испытуемый не давал ответа (даже когда это было нужно)
a <- dat[!is.na(dat$key_resp_1.rt), c("key_resp_1.corr", "key_resp_1.rt", "set_type1", "participant")]
names(a) <- c("key_resp.corr", "key_resp.rt", "set_type", "participant")
b <- dat[!is.na(dat$key_resp_2.rt), c("key_resp_2.corr", "key_resp_2.rt", "set_type2", "participant")]
names(b) <- c("key_resp.corr", "key_resp.rt", "set_type", "participant")
c <- dat[!is.na(dat$key_resp_3.rt), c("key_resp_3.corr", "key_resp_3.rt", "set_type3", "participant")]
names(c) <- c("key_resp.corr", "key_resp.rt", "set_type", "participant")
d <- dat[!is.na(dat$key_resp_4.rt), c("key_resp_4.corr", "key_resp_4.rt", "set_type4", "participant")]
names(d) <- c("key_resp.corr", "key_resp.rt", "set_type", "participant")
nn <- c("a","b","c","d")

dat <- rbind(a,b, c,d)

# Избавляемся от всех случаев, когда испытуемые давали неверные ответы
dat <- dat[dat$key_resp.corr == "1",]

# Считаем процент правильных ответов для каждого испытуемого 
acc <- dat%>%group_by(participant)%>%summarise(acc = sum(key_resp.corr)/120)
accc <- acc[acc$acc<0.6, "participant"]

# тут удаляем всех плохих
dat <- dat[dat$participant != 'and',]
dat <- dat[dat$participant != 'Egor',]
dat <- dat[dat$participant != 'Grishutina2',]
dat <- dat[dat$participant != 'zoya',]
dat <- dat[dat$participant != 'MashaA',]
dat <- dat[dat$participant != 'erenkova',]
dat <- dat[dat$participant != 'gamaeva',]
dat <- dat[dat$participant != 'sattarova',]
dat <- dat[dat$participant != 'Platon',]
dat <- dat[dat$participant != 'Burnip',]
dat <- dat[dat$participant != 'Zabyvaev',]
dat <- dat[dat$participant != 'probnaya proba',]
dat <- dat[dat$participant != 'sara',]
dat <- dat[dat$participant != 'IGOLKINA',]
dat <- dat[dat$participant != 'Gronas',]
dat <- dat[dat$participant != 'Tonkikh',]
dat <- dat[dat$participant != 'Nikonova',]
dat <- dat[dat$participant != 'Dabaeva',]

# Удаляем все, что нам уже не нужно и не будет нужно
remove(a,b,c,d, dat1)

# и удаляем колонку с правильными ответами, ибо теперь у нас только правильные и есть
dat <-  dat[, c("key_resp.rt", "set_type", "participant")]
names(dat) <- c("rt", "set_type", "participant")

# Еще удаляем все ответы на несогласованные триады
dat <- dat[!dat$set_type == "no",]

# Мы группируем это все по каждому типу триад для каждого испытуемого и записываем новую переменную, в которой будет 
# это среднее значения ВР, и каждый из группирующих факторов (испытуемый и тип триады)
m <- dat%>%group_by(set_type)%>%group_by(participant, add =T )%>%summarise(mrt = mean(rt), msd = sd(rt))
wilcox.test(m$mrt[m$set_type == "neu"], m$mrt[m$set_type == "pos"], paired = T)

# А тут мы перевели секунды в милисекунды, ибо так принято
m$mrt <- m$mrt*1000
library(ggplot2)

ggplot(data = m, aes(set_type, mrt))+
  stat_summary(aes(), fun.data = "mean_se", geom = 'point', size = 4)+
   stat_summary(aes(), fun.data = "mean_se", geom = "errorbar", linetype =1, width = 0.2)+ #+ если возвращать этот кусок, нужно еще сделать as.numeric(set_type)  stat_summary(aes(), geom = "errorbar",  width = 0.1)+
  xlab("Emotion")+
  ylab("Reaction time (ms)")



